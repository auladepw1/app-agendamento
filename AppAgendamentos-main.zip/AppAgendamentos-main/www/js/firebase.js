// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
	apiKey: "AIzaSyB205vWNGpscmvXcH7yZLBYjkfrf4FWmkw",
    authDomain: "app-agendamento-b7fd4.firebaseapp.com",
    projectId: "app-agendamento-b7fd4",
    storageBucket: "app-agendamento-b7fd4.appspot.com",
    messagingSenderId: "519331833263",
    appId: "1:519331833263:web:e5a2d1e3119c3bafc6bb5a",
    measurementId: "G-BMMYL3W3FM"
 };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();